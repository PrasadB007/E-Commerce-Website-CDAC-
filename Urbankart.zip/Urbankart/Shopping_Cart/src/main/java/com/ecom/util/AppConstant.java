package com.ecom.util;

public class AppConstant {

	public static final long UNLOCK_DURATION_TIME = 3000;
			//1 * 60 * 60 * 1000;

	public static final long ATTEMPT_TIME = 3;
}
